ShopEz -an online e-commerce website for one stop shopping purpose
